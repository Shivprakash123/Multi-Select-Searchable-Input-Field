/** Get Dashboard crypto Top selling data */

export const API_SUCCESS = "API_SUCCESS";
export const API_FAIL = "API_FAIL";
export const GET_WALLET_DATA = "GET_WALLET_DATA";