export const API_SUCCESS = 'API_SUCCESS';
export const API_FAIL = 'API_FAIL';
export const GET_VISITOR_DATA = 'GET_VISITOR_DATA';